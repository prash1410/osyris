import React from 'react';

import './Planner.css';

import cloneDeep from 'lodash/cloneDeep';

import GridRow from './GridRow/GridRow.js';
import StoryMaker from './StoryMaker/StoryMaker.js';

class Planner extends React.Component
{
  constructor(props)
  {
    super(props);
    this.state = {showStoryMaker:false, selectedLevel:0, levelButtonsClasses:['level-button-week-active',
                                                             'level-button-month',
                                                             'level-button-quarter',
                                                             'level-button-year']};

    this.editStoryHandler = this.editStoryHandler.bind(this);
    this.cellClickhandler = this.cellClickhandler.bind(this);
  }

  cellClickhandler(argument)
  {
    this.setState(argument);
  }

  levelChanged = viewIndex =>
  {

    var viewClassList = this.state.levelButtonsClasses;
    for (var i = 0; i < viewClassList.length; i++)
    {
      viewClassList[i] = viewClassList[i].replace('-active', '');
      if (i === viewIndex) viewClassList[i] = viewClassList[i] + '-active';
    }

    this.setState({levelButtonsClasses:viewClassList, selectedLevel:viewIndex});
  };


  editStoryHandler(argument)
  {
    var project = argument.payload.project;
    var storyID = argument.payload.storyID;

    for (var story of this.props.projects[project].stories)
    {
      if (story.storyID === storyID)
      {
        argument.payload['storyMakerPayload'] = story;
        this.setState(argument);
        break;
      }
    }
  }

  render()
  {
    const getOrdinal = (number) => {
      let selector;

      if (number <= 0) {
        selector = 4;
      } else if ((number > 3 && number < 21) || number % 10 > 3) {
        selector = 0;
      } else {
        selector = number % 10;
      }

      return number + ['th', 'st', 'nd', 'rd', ''][selector];
    };


    function getMonday(d, dateAsString)
    {
      d = new Date(d);
      var day = d.getDay(),
      diff = d.getDate() - day + (day === 0 ? -6:1); // adjust when day is sunday
      var firstDay = new Date(d.setDate(diff));
      if (dateAsString) return firstDay.getDate() + '-' + (firstDay.getMonth()+1) + '-' + firstDay.getFullYear();
      else return firstDay;
    }
    
    var periodCounter = {};
    var innerPeriodCounter = {};
    var cellWidth = 6;
    var marginLeft, marginRight, marginTop, marginBottom = '0.2em';
    //var background = '#444444';
    var background = 'transparent';
    if (this.state.selectedLevel === 1) cellWidth = 2.9;
    else if (this.state.selectedLevel === 2) cellWidth = 0.87;
    else if (this.state.selectedLevel === 3) cellWidth = 0.22;

    var defaultGridCellStyle = {background: background,
                                width: cellWidth.toString() + 'em',
                                color: '#EDEDED',
                                clickable:true, 
                                marginLeft:marginLeft, 
                                marginRight:marginRight, 
                                marginTop:marginTop, 
                                marginBottom:marginBottom};

    var defaultGridCellData = {text:'', cellType:'blank-cell'};

    var grid = [];

    var projectArray = [{'text':'Projects',
                         'background':'#444444'}];

    var storiesArray = [];

    function sortAscending( a, b )
    {
      if ( new Date(a.startDate) < new Date(b.startDate) )
      {
        return -1;
      }
      if ( new Date(a.startDate) > new Date(b.startDate) )
      {
        return 1;
      }
      return 0;
    }



    var sortedProjects = [];
    for (let project in this.props.projects)
    {
      sortedProjects.push({project:project, order:this.props.projects[project].order});
    }

    sortedProjects.sort((a,b) => (a.order > b.order) ? 1 : ((b.order > a.order) ? -1 : 0))
  

    for (let project of sortedProjects)
    {
      project = project.project;

      var rowCollector = [0];
      var stories = this.props.projects[project].stories;
      if (typeof stories !== 'undefined')
      {
        stories.sort(sortAscending);
        var projectStoriesArray = [];
        for (var story of stories)
        {
          var row = 0;
          var blackListedRows = [];

          var storyStartDate = new Date(story.startDate);
          var storyEndDate = new Date(story.endDate);

          var formattedStoryStartDate  = storyStartDate.getDate() + '-' + (storyStartDate.getMonth()+1) + '-' + storyStartDate.getFullYear();
          //if (this.state.selectedLevel > 1) formattedStoryStartDate = '1-' + (storyStartDate.getMonth()+1) + '-' + storyStartDate.getFullYear();
          var formattedStartDate  = storyStartDate.getDate() + '-' + storyStartDate.toLocaleString('en-us', {month:'short'}) + "-" + storyStartDate.getFullYear().toString().substr(-2);

          var formattedStoryEndDate  = storyEndDate.getDate() + '-' + (storyEndDate.getMonth()+1) + '-' + storyEndDate.getFullYear();
          //if (this.state.selectedLevel > 1) formattedStoryEndDate = '1-' + (storyEndDate.getMonth()+1) + '-' + storyEndDate.getFullYear();
          var formattedEndDate  = storyEndDate.getDate() + '-' + storyEndDate.toLocaleString('en-us', {month:'short'}) + "-" + storyEndDate.getFullYear().toString().substr(-2);

          if (projectStoriesArray.length > 0)
          {
            for (var pushedStory of projectStoriesArray)
            {
              var collisionFlag = 0;
              var pushedStartDate = new Date(pushedStory.storyStartDate);
              var pushedEndDate = new Date(pushedStory.storyEndDate);
              //var pushedStartMonday = pushedStory.storyStartMonday;
              //var pushedEndMonday = pushedStory.storyEndMonday;

              if (storyStartDate <= pushedEndDate && storyStartDate >= pushedStartDate) collisionFlag += 1;

              if (storyEndDate <= pushedEndDate && storyEndDate >= pushedStartDate) collisionFlag += 1;

              if (pushedStartDate <= storyEndDate && pushedStartDate >= storyStartDate) collisionFlag += 1;

              if (pushedEndDate <= storyEndDate && pushedEndDate >= storyStartDate) collisionFlag += 1;

              if (formattedStoryStartDate === pushedStory.formattedStoryStartDate || formattedStoryStartDate === pushedStory.formattedStoryEndDate || formattedStoryEndDate === pushedStory.formattedStoryStartDate || formattedStoryEndDate === pushedStory.formattedStoryEndDate) collisionFlag += 1;

              //if (storyStartMonday === pushedStartMonday || storyStartMonday === pushedEndMonday) collisionFlag += 1;

              //if (storyEndMonday === pushedStartMonday || storyEndMonday === pushedEndMonday) collisionFlag += 1;

              if (collisionFlag !== 0)
              {

                var pushedRow = pushedStory.row;
                blackListedRows.push(pushedRow);
                blackListedRows.sort(function(a, b) {return a - b;});

                for (var i = 0; i <= Math.max.apply(Math, blackListedRows); i++)
                {
                  if (i === Math.max.apply(Math, blackListedRows)) row = Math.max.apply(Math, blackListedRows) + 1
                  else if (blackListedRows.indexOf(i) < 0)
                  {
                    row = i;
                    break;
                  }
                }
              }
            }
            rowCollector.push(row);
          }

          projectStoriesArray.push({project:project,
                                     storyStartDate:storyStartDate,
                                     storyEndDate:storyEndDate,
                                     storyName:story.storyName,
                                     storyID:story.storyID,
                                     formattedStoryStartDate:formattedStoryStartDate,
                                     formattedStartDate:formattedStartDate,
                                     formattedStoryEndDate:formattedStoryEndDate,
                                     formattedEndDate:formattedEndDate,
                                     row:row});
        }
        for (var projectStory of projectStoriesArray)
        {
          storiesArray.push(projectStory);
        }
      }
      for (var i = 0; i <= Math.max.apply(Math, rowCollector); i++)
      {
        projectArray.push({'text':project, 'background':this.props.projects[project].color, 'row':i});
      }
    }

    var trackStartDate = getMonday(new Date(), false);
    var trackEndDate = new Date();

    if (this.state.selectedLevel === 0)
    {
      trackStartDate.setDate(trackStartDate.getDate() - 7);
      trackEndDate.setDate(trackEndDate.getDate() + 30);
      trackEndDate = getMonday(trackEndDate, false);
      trackEndDate.setDate(trackEndDate.getDate() - 1);
    }
    else if (this.state.selectedLevel === 1)
    {
      var date = new Date();
      trackStartDate = new Date(date.getFullYear(), date.getMonth() - 1, 1);
      trackEndDate = new Date(date.getFullYear(), date.getMonth() + 3, 0);
    }
    else if (this.state.selectedLevel === 2)
    {
      var date = new Date();
      trackStartDate = new Date(date.getFullYear(), date.getMonth() - 3, 1);
      var startingQuarter =  parseInt(trackStartDate.getMonth() / 3 ) + 1 ;
      trackStartDate = new Date(trackStartDate.getFullYear(), 3*(startingQuarter), 1);

      trackEndDate = new Date(date.getFullYear(), date.getMonth() + 6, 1);
      var endingQuarter =  parseInt(trackEndDate.getMonth() / 3 ) + 1 ;
      trackEndDate = new Date(trackEndDate.getFullYear(), 3*(endingQuarter-1), 1);
      trackEndDate.setDate(trackEndDate.getDate() - 1);
    }
    else if (this.state.selectedLevel === 3)
    {
      var date = new Date();
      trackStartDate = new Date(date.getFullYear(), 0, 1);
      trackEndDate = new Date(date.getFullYear() + 1, 0, 1);
      trackEndDate.setDate(trackEndDate.getDate() - 1);
    }


    if (storiesArray.length > 0)
    {
      var storiesStartArray = [];
      var storiesEndArray = [];

      for (var story of storiesArray)
      {
        storiesStartArray.push(story.storyStartDate);
        storiesEndArray.push(story.storyEndDate);
      }

      var firstStoryStartDate = new Date(Math.min.apply(null,storiesStartArray));
      var lastStoryEndDate = new Date(Math.max.apply(null,storiesEndArray));

      if (this.state.selectedLevel === 0)
      {
        trackStartDate = new Date(firstStoryStartDate);
        trackStartDate.setDate(trackStartDate.getDate());
        trackStartDate = getMonday(trackStartDate, false);

        trackEndDate = new Date(lastStoryEndDate);
        trackEndDate.setDate(trackEndDate.getDate() + 30);
        trackEndDate = getMonday(trackEndDate, false);
        trackEndDate.setDate(trackEndDate.getDate() - 1);
      }
      else if (this.state.selectedLevel === 1)
      {
        trackStartDate = new Date(firstStoryStartDate.getFullYear(), firstStoryStartDate.getMonth(), 1);
        trackEndDate = new Date(lastStoryEndDate.getFullYear(), lastStoryEndDate.getMonth() + 3, 0);
      }
      else if (this.state.selectedLevel === 2)
      {
        trackStartDate = new Date(firstStoryStartDate.getFullYear(), firstStoryStartDate.getMonth() - 3, 1);
        var startingQuarter =  parseInt(trackStartDate.getMonth() / 3 ) + 1 ;
        trackStartDate = new Date(trackStartDate.getFullYear(), 3*(startingQuarter), 1);

        trackEndDate = new Date(lastStoryEndDate.getFullYear(), lastStoryEndDate.getMonth() + 6, 1);
        var endingQuarter =  parseInt(trackEndDate.getMonth() / 3 ) + 1 ;
        trackEndDate = new Date(trackEndDate.getFullYear(), 3*(endingQuarter-1), 1);
        trackEndDate.setDate(trackEndDate.getDate() - 1);
      }
      else if (this.state.selectedLevel === 3)
      {
        trackStartDate = new Date(firstStoryStartDate.getFullYear(), 0, 1);
        trackEndDate = new Date(lastStoryEndDate.getFullYear() + 1, 0, 1);
        trackEndDate.setDate(trackEndDate.getDate() - 1);
      }
    }

    var days = [''];
    var weekDays = [''];
    var periods = [''];

    while (trackStartDate <= trackEndDate)
    {
      var day = trackStartDate.getDate() + '-' + (trackStartDate.getMonth()+1) + '-' + trackStartDate.getFullYear();
      days.push(day);

      var period = null;

      if (this.state.selectedLevel === 0)
      {
        var monday = getMonday(trackStartDate, false);
        //var formattedMonday = 'Week of ' + getOrdinal(pushDate.getDate()) + ' ' + pushDate.toLocaleString('en-us', {month:'short'}) + " '" + pushDate.getFullYear().toString().substr(-2);
        period = 'Week of ' + getOrdinal(monday.getDate()) + ' ' + monday.toLocaleString('en-us', {month:'long'}) + " " + monday.getFullYear().toString();
      }
      else if (this.state.selectedLevel === 1)
      {
        //period = trackStartDate.toLocaleString('en-us', {month:'long'}) + " '" + trackStartDate.getFullYear().toString().substr(-2);
        period = trackStartDate.toLocaleString('en-us', {month:'long'}) + " " + trackStartDate.getFullYear().toString();
      }
      else if (this.state.selectedLevel === 2)
      {
        var startingQuarter =  parseInt(trackStartDate.getMonth() / 3 ) + 1;
        period = 'Q' + startingQuarter.toString() + " " + trackStartDate.getFullYear().toString();
      }
      else if (this.state.selectedLevel === 3)
      {
        period = trackStartDate.getFullYear().toString();
      }

      if (!(period in periodCounter)) periodCounter[period] = 1;
      else periodCounter[period] = periodCounter[period] + 1;

      if(periods.indexOf(period) === -1) periods.push(period);

      if (this.state.selectedLevel === 0) weekDays.push(new Date(trackStartDate).toLocaleString('en-us', {weekday:'short'}));
      else if (this.state.selectedLevel === 1) weekDays.push(new Date(trackStartDate).getDate());
      else 
      {
        var monthYear = '';
        if (this.state.selectedLevel === 2) monthYear = new Date(trackStartDate).toLocaleString('en-us', {month:'long'}) + " " + trackStartDate.getFullYear().toString();
        else monthYear = new Date(trackStartDate).toLocaleString('en-us', {month:'short'}) + " " + trackStartDate.getFullYear().toString();


        if(weekDays.indexOf(monthYear) === -1) weekDays.push(monthYear);
        
        if (!(monthYear in innerPeriodCounter)) innerPeriodCounter[monthYear] = 1;
        else innerPeriodCounter[monthYear] = innerPeriodCounter[monthYear] + 1;
      }
      
      trackStartDate.setDate(trackStartDate.getDate() + 1);
      //else trackStartDate = new Date(trackStartDate.setMonth(trackStartDate.getMonth() + 1));
    }

    console.log(innerPeriodCounter);

    for (var rowCounter = -1; rowCounter < projectArray.length; rowCounter++)
    {
      var dataArray = [];
      var styleArray = [];
      var dropIndices = [];

      for (var columnCounter = 0; columnCounter < days.length; columnCounter++)
      {
        var customGridCellStyle = cloneDeep(defaultGridCellStyle);
        var customGridCellData = cloneDeep(defaultGridCellData);

        customGridCellData['startDate'] = days[columnCounter];
        //var parts = days[columnCounter].split('-');
        //var formattedDate = new Date(parts[2], parts[1] - 1, parts[0]);
        //formattedDate = formattedDate.getDate() + '-' + formattedDate.toLocaleString('en-us', {month:'short'}) + "-" + formattedDate.getFullYear().toString().substr(-2);
        //customGridCellData['formattedStartDate'] = formattedDate;
        customGridCellData['formattedStartDate'] = null;
        customGridCellData['formattedEndDate'] = null;

        if(rowCounter === -1 && columnCounter < periods.length)
        {
          customGridCellData['text'] = periods[columnCounter];
          customGridCellData['cellType'] = 'date-cell';
          customGridCellStyle['clickable'] = false;
          customGridCellStyle['background'] = '#444444';
          if (columnCounter === 0)
          {
            //customGridCellStyle['background'] = 'transparent';
            customGridCellStyle['width'] = '15em';
          } 
          else if (columnCounter > 0 ) customGridCellStyle['width'] = (cellWidth * periodCounter[periods[columnCounter]]).toString() + 'em';
          
        }

        if(rowCounter === 0)
        {
          if (this.state.selectedLevel < 2)
          {
            customGridCellData['text'] = weekDays[columnCounter];
            customGridCellData['cellType'] = 'date-cell';
            customGridCellStyle['clickable'] = false;
            customGridCellStyle['background'] = '#444444';
          }
          else if (this.state.selectedLevel >= 2 && columnCounter < weekDays.length)
          {
            customGridCellData['text'] = weekDays[columnCounter].split(' ')[0];
            customGridCellData['cellType'] = 'date-cell';
            customGridCellStyle['clickable'] = false;
            customGridCellStyle['background'] = '#444444';
            if (columnCounter === 0)
            {
              //customGridCellStyle['background'] = 'transparent';
              customGridCellStyle['width'] = '15em';
            } 
            else if (columnCounter > 0 ) customGridCellStyle['width'] = (cellWidth * innerPeriodCounter[weekDays[columnCounter]]).toString() + 'em';
          }
          
        }


        if (columnCounter === 0 && rowCounter > -1)
        {
          customGridCellData['text'] = projectArray[rowCounter].text;
          customGridCellData['cellType'] = 'project-cell';
          customGridCellStyle['background'] = projectArray[rowCounter].background;
          customGridCellStyle['clickable'] = false;
          customGridCellStyle['width'] = '15em';
          //if (this.state.selectedLevel === 4) customGridCellStyle['marginRight'] = '0.2em';
          customGridCellStyle['marginLeft'] = '0.2em';
        }

        if (rowCounter > -1)
        {
          customGridCellData['project'] = projectArray[rowCounter].text;
          customGridCellStyle['projectColor'] = projectArray[rowCounter].background;

          for (var story of storiesArray)
          {
            var storyStartIndex = days.indexOf(story.formattedStoryStartDate);
            var storyEndIndex = days.indexOf(story.formattedStoryEndDate);

            if ( columnCounter === storyStartIndex && customGridCellData['project'] === story.project && projectArray[rowCounter].row === story.row)
            {
              customGridCellData['formattedStartDate'] = story.formattedStartDate;
              customGridCellData['formattedEndDate'] = story.formattedEndDate;
              customGridCellData['text'] = story.storyName;
              customGridCellData['storyID'] = story.storyID;
              customGridCellData['cellType'] = 'story-cell';
              customGridCellStyle['background'] = projectArray[rowCounter].background;
              var newWidth = cellWidth * ((storyEndIndex - storyStartIndex) + 1);
              customGridCellStyle['width'] = newWidth.toString() + 'em';

              for (var i = storyStartIndex + 1; i <= storyEndIndex; i++) dropIndices.push(i);
            }
          }
        }

        styleArray.push(customGridCellStyle);
        dataArray.push(customGridCellData);
      }

      if (rowCounter === -1)
      {
        dataArray.splice(periods.length);
        styleArray.splice(periods.length);
      }
      else if (rowCounter === 0 && this.state.selectedLevel > 1)
      {
        dataArray.splice(weekDays.length);
        styleArray.splice(weekDays.length);
      }
      else
      {
        dataArray = dataArray.filter(function(value, index)
        {
          return dropIndices.indexOf(index) == -1;
        });

        styleArray = styleArray.filter(function(value, index)
        {
          return dropIndices.indexOf(index) == -1;
        });
      }

      grid.push(<GridRow data={dataArray} style={styleArray} handler={this.cellClickhandler} editStoryHandler={this.editStoryHandler} />)
    }

    var storyMaker = null;
    if (this.state.showStoryMaker)
    {
      console.log(this.state.payload);
      storyMaker = <StoryMaker handler={this.cellClickhandler} payload={this.state.payload} deleteStoryHandler={this.props.deleteStoryHandler} addStoryHandler={this.props.addStoryHandler} editStoryHandler={this.props.editStoryHandler} teamMembers={this.props.teamMembers}/>
    }

    return (
      <div className='planner-layout'>
        {storyMaker}
        <div className='level-buttons-container'>
          <div onClick={() => this.levelChanged(0)}  className={this.state.levelButtonsClasses[0]}>
            Weekly
          </div>
          <div className='blank-space'/>
          <div onClick={() => this.levelChanged(1)} className={this.state.levelButtonsClasses[1]}>
            Monthly
          </div>
          <div className='blank-space'/>
          <div onClick={() => this.levelChanged(2)} className={this.state.levelButtonsClasses[2]}>
            Quarterly
          </div>
          <div className='blank-space'/>
          <div onClick={() => this.levelChanged(3)} className={this.state.levelButtonsClasses[3]}>
            Yearly
          </div>
        </div>
        <div className='grid-container'>
          {grid}
        </div>
      </div>
    );
  }
}

export default Planner;
