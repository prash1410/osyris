import React from 'react';

import './GridCell.css';
import '../../../css/all.css';

import Tooltip from '@material-ui/core/Tooltip';
import Zoom from '@material-ui/core/Zoom';

class GridCell extends React.Component
{
  constructor(props)
  {
    super(props);
    this.state = {showPopup:false, popupAnchorElement:null};
    this.onGridCellHover = this.onGridCellHover.bind(this);
  }

  onGridCellHover(event)
  {
    console.log('fired');
    if (this.state.showPopup)
    {
      this.setState({popupAnchorElement: null,
                     showPopup: false});
    }
    else
    {
      this.setState({popupAnchorElement: event.currentTarget,
                     showPopup: true});
    }
  }

  createStory = event =>
  {
    this.props.handler({showStoryMaker:true,
                        payload:{startDate:this.props.startDate,
                                 project:this.props.project,
                                 projectColor:this.props.projectColor}});
  };

  editStory = event =>
  {
    this.props.editStoryHandler({showStoryMaker:true,
                                payload:{startDate:this.props.startDate,
                                         project:this.props.project,
                                         projectColor:this.props.projectColor,
                                         storyID:this.props.storyID}});
  };

  render()
  {
    const { width = '10em' } = this.props;
    const {background = '#444444'} = this.props;
    const {color = '#EDEDED'} = this.props;
    const {clickable = true} = this.props;
    const {project = null} = this.props;
    const {projectColor = 'black'} = this.props;
    const {cellType = 'blank-cell'} = this.props;
    const {marginLeft = '0.1em'} = this.props;
    const {marginRight = '0.1em'} = this.props;
    const {marginTop = '0.1em'} = this.props;
    const {marginBottom = '0.1em'} = this.props;

    var cellText = this.props.text;

    var tooltipContent = (<div className='grid-cell-tooltip'>
                              <div className='grid-cell-tooltip-header' style={{background:this.props.projectColor}}>
                                <strong>{project}</strong>
                              </div>
                              <div className='grid-cell-tooltip-body'>
                                Create Story On: {this.props.formattedStartDate}
                              </div>
                              
                            </div>);

    var cellLayout = (
      //<Tooltip TransitionComponent={Zoom} title={tooltipContent} placement="top" arrow enterDelay={500}>
    <div style={{ width: width}} className='grid-cell-container-hoverable'>
                        <div style={{ border: '0.2em solid', borderColor:projectColor, background:projectColor, opacity:0, color:color, marginLeft:marginLeft, marginRight:marginRight,  marginTop:marginTop, marginBottom:marginBottom}} className='grid-cell'>
                          {cellText}
                        </div>
                        <div style={{ border: '0.2em solid', borderColor:projectColor, background:projectColor, marginLeft:marginLeft, marginRight:marginRight,  marginTop:marginTop, marginBottom:marginBottom }}className='overlay' onClick={this.createStory} >
                          
                        </div>
                      </div>
                      //</Tooltip>
                      );

    if (!clickable)
    {
      cellLayout = (<div style={{ width: width}} className='grid-cell-container'>
                      <div style={{ border: '0.2em solid', borderColor:background, background:background, color:color, marginLeft:marginLeft, marginRight:marginRight,  marginTop:marginTop, marginBottom:marginBottom}} className='grid-cell'>
                        {cellText}
                      </div>
                    </div>);
    }

    if (cellType === 'story-cell')
    {
      tooltipContent = (<div className='story-tooltip'>
                              <div className='story-tooltip-header' style={{background:background}}>
                                <strong>{project}:</strong>&nbsp;{this.props.text}
                              </div>
                              <div className='story-tooltip-body'>
                                <div>Starts On: {this.props.formattedStartDate}</div>
                                <div style={{marginTop:'0.7em'}}>Ends On: {this.props.formattedEndDate}</div>
                              </div>
                              
                            </div>);
      cellLayout = (<>
      <Tooltip TransitionComponent={Zoom} title={tooltipContent} placement="top" arrow enterDelay={100}>
        <div style={{ width: width}} className='grid-cell-container-hoverable'>
                      <div style={{ border: '0.2em solid', borderColor:background, background:background, color:color, marginLeft:marginLeft, marginRight:marginRight,  marginTop:marginTop, marginBottom:marginBottom}} className='grid-cell'>
                        {cellText}
                      </div>

                      <div style={{ border: '0.2em solid', borderColor:projectColor, background:projectColor, marginLeft:marginLeft, marginRight:marginRight,  marginTop:marginTop, marginBottom:marginBottom }}className='overlay' onClick={this.editStory} >
                        <i style={{ color:'#EDEDED'}} className="fas fa-pencil-alt fa-2x"></i>
                      </div>
                    </div>
                    </Tooltip>
                  </>);
    }

    return (
      <>
        {cellLayout}  
      </>
    );
  }
}

export default GridCell;
