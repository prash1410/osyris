import React from 'react';
import './LeaveCard.css';


class LeaveCard extends React.Component
{
  constructor(props)
  {
    super(props);
  }

  deleteLeave = event =>
  {
    this.props.deleteLeave(this.props.leave);
  };

  render()
  {
    return (
            <div className='leave-tm-card'>
                <div className='leave-tm-card-right-section'>
                  <div style={{background:this.props.teamMembers[this.props.leave.teamMember].color}} className='tm-team-member-name-wrapper'>
                    &nbsp;&nbsp;&nbsp;{this.props.leave.teamMember}
                    <div className='tm-delete-leave-tm-button-container'>
                      <i onClick={this.deleteLeave} className="fas fa-trash-alt delete-leave-tm-button"></i>&nbsp;&nbsp;&nbsp;
                    </div>
                  </div>
                  <div className='leave-tm-details-section'>
                    <div className='leave-tm-icon-container'>
                      <i style={{ color:'lightgray'}} className={this.props.leave.leaveType === 'Casual' ? "fas fa-umbrella-beach fa-2x" : "fas fa-user-md fa-2x"}></i>
                    </div>
                    <div className='tm-days-count-section'>
                      {this.props.leave.days} {this.props.leave.days > 1 ? "days" : "day"}
                    </div>
                    <div className='leave-tm-days-section'>
                      <div className='leave-tm-start-date'>
                        From: {this.props.formattedLeaveStartDate}
                      </div>
                      <div className='leave-tm-end-date'>
                        Until: {this.props.formattedLeaveEndDate}
                      </div>
                    </div>

                  </div>
                </div>
               </div>
              
    );
  }

}

export default LeaveCard;
