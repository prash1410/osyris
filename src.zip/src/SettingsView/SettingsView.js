import React from 'react';
import './SettingsView.css';


class SettingsView extends React.Component
{
  constructor(props)
  {
    super(props);
  }

  render()
  {
    return (
      <>This is settings view</>
    );
  }

}

export default SettingsView;
