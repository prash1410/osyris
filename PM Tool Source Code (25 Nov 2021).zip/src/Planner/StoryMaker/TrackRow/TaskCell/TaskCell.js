import React from 'react';

import './TaskCell.css';
import '../../../../css/all.css';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';

import Tooltip from '@material-ui/core/Tooltip';
import Zoom from '@material-ui/core/Zoom';


class TaskCell extends React.Component
{
  constructor(props)
  {
    super(props);
    this.state = {menuAnchorElement:null,
                  showMenu:false};

    this.showMenu = this.showMenu.bind(this);
    this.closeMenu = this.closeMenu.bind(this);
    this.deleteTrack = this.deleteTrack.bind(this);
    this.moveTrackUp = this.moveTrackUp.bind(this);
    this.moveTrackDown = this.moveTrackDown.bind(this);
  }

  showMenu(event)
  {
    this.setState({menuAnchorElement: event.currentTarget,
                   showMenu: !this.state.showMenu});
  };

  closeMenu(event)
  {
    this.setState({menuAnchorElement: null,
                   showMenu: !this.state.showMenu});
  };

  deleteTrack(event)
  {
    this.props.deleteTrackHandler(this.props.trackIndex);
    this.closeMenu();
  };

  moveTrackUp(event)
  {
    this.props.moveTrackHandler(this.props.trackIndex, 1);
    this.closeMenu();
  };

  moveTrackDown(event)
  {
    this.props.moveTrackHandler(this.props.trackIndex, 0);
    this.closeMenu();
  };

  createStory = event =>
  {
    this.props.handler({showTaskCreator:true,
                        taskCreatorPayload:{startDate:this.props.date,
                                            trackIndex:this.props.trackIndex,
                                            taskID:this.props.taskID}});
  };

  onTrackNameChange = event =>
  {
    var tracks = this.props.tracks;
    tracks[this.props.trackIndex] = event.target.value;
    this.props.trackNameChangehandler({tracks:tracks});
  };

  render()
  {
    const { width = '15em' } = this.props;
    const {background = '#444444'} = this.props;
    const {color = '#EDEDED'} = this.props;
    const {clickable = true} = this.props;
    const {cellType = ''} = this.props;
    const {trackIndex = null} = this.props;
    const {tracks = null} = this.props;
    var cellText = this.props.text;

    var cellLayout = (<div style={{ width: width}} className='task-cell-container-hoverable'>
                        <div style={{ background:background, color:color}} className='task-cell'>
                          {cellText}
                        </div>
                        <div className='task-cell-overlay' onClick={this.createStory} >
                          <i className="fas fa-plus-circle fa-2x"></i>
                        </div>
                      </div>);

    if (!clickable)
    {
      cellLayout = (<div style={{ width: width}} className='task-cell-container'>
                      <div style={{ background:background, color:color}} className='task-cell'>
                        {cellText}
                      </div>
                    </div>);
    }

    if (!clickable && cellType === 'track-cell')
    {
      var menu = (<Menu id="fade-menu" anchorEl={this.state.menuAnchorElement} open={this.state.showMenu} onClose={this.closeMenu} keepMounted>
                    <MenuItem onClick={this.moveTrackUp}><span className='move-menu-item'><i className="fas fa-arrow-up"></i>&nbsp;&nbsp;Move Track Up</span></MenuItem>
                    <MenuItem onClick={this.moveTrackDown}><span className='move-menu-item'><i className="fas fa-arrow-down"></i>&nbsp;&nbsp;Move Track Down</span></MenuItem>
                    <MenuItem onClick={this.deleteTrack}><span className='delete-menu-item'><i className="fas fa-trash-alt"></i>&nbsp;&nbsp;Delete Track</span></MenuItem>
                  </Menu>);

      if (trackIndex === 0)
      {
        menu = (<Menu id="fade-menu" anchorEl={this.state.menuAnchorElement} open={this.state.showMenu} onClose={this.closeMenu} keepMounted>
                    <MenuItem onClick={this.moveTrackDown}><span className='move-menu-item'><i className="fas fa-arrow-down"></i>&nbsp;&nbsp;Move Track Down</span></MenuItem>
                    <MenuItem onClick={this.deleteTrack}><span className='delete-menu-item'><i className="fas fa-trash-alt"></i>&nbsp;&nbsp;Delete Track</span></MenuItem>
                  </Menu>);
      }
      else if (trackIndex === tracks.length - 1)
      {
        menu = (<Menu id="fade-menu" anchorEl={this.state.menuAnchorElement} open={this.state.showMenu} onClose={this.closeMenu} keepMounted>
                    <MenuItem onClick={this.moveTrackUp}><span className='move-menu-item'><i className="fas fa-arrow-up"></i>&nbsp;&nbsp;Move Track Up</span></MenuItem>
                    <MenuItem onClick={this.deleteTrack}><span className='delete-menu-item'><i className="fas fa-trash-alt"></i>&nbsp;&nbsp;Delete Track</span></MenuItem>
                  </Menu>);
      }

      cellLayout = (<div style={{ width: width}} className='task-cell-container'>
                      <div style={{ background:background, color:color}} className='task-cell'>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        <input onChange={this.onTrackNameChange} className='track-name-input' value={cellText} type='text'/>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        <i onClick={this.showMenu} className="fas fa-ellipsis-v fa-lg track-menu"></i>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                      </div>
                        {menu}
                    </div>);
    }

    if (cellType === 'filled-cell')
    {
      var tooltipContent = (<div className='story-tooltip'>
                              <div className='story-tooltip-header' style={{background:background}}>
                                <strong>{this.props.tracks[this.props.trackIndex]}:</strong>&nbsp;{this.props.text}
                              </div>
                              <div className='story-tooltip-body'>
                                <div>Starts On: {this.props.taskStartDate}</div>
                                <div style={{marginTop:'0.7em'}}>Ends On: {this.props.taskEndDate}</div>
                                <hr/>
                                <div style={{marginTop:'0.7em'}}>Assigned To: {this.props.assignedTo}</div>
                              </div>
                              
                            </div>);

      cellLayout = (<Tooltip TransitionComponent={Zoom} title={tooltipContent} placement="top" arrow enterDelay={100}>
      <div style={{ width: width}} className='task-cell-container-hoverable'>
                      <div style={{ background:background, color:color}} className='task-cell'>
                        {cellText}
                      </div>
                      <div style={{ background:background}} className='task-cell-overlay' onClick={this.createStory} >
                        <i className="fas fa-pencil-alt fa-2x"></i>
                      </div>
                    </div>
                    </Tooltip>);
    }


    return (
      <>{cellLayout}</>
    );
  }
}

export default TaskCell;
